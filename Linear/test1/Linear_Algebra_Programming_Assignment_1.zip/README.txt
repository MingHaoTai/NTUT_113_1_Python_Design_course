Linear Algebra Programming Assignment #1    (2024/10/02)
---------------------------------------------------------
Input the question number (a, b, c, d, e, f)
If it is not only one small question in the big question, please input the NO (1, 2, 3)
You will get the result!
When the question finished, the program will repeat
But if you input 'end' when 'Input the question number', the program will end