This is a program for solving the questions of linear algebra of finding the 
eigenvalues and the eigenvector corresponding to eigenvectors.

Eigenvalue: An n×n matrix A isn't equal to 0. Ax = cx, where c is a scalar. The c is called an eigenvalue of A.

Eigenvector:  Three n×n matrices A, B, P, p. A is a diagonalizable matrix, B is the diagonal matrix where the diagonal elements from A, P is an eigenvector, and p is the inverse matrix of P. 
A = PBp

If the matrix is empty or equal to 0, it will not have any eigenvalues.

1. Input the matrix no, like a, b, c, x, z.
2. The program will calculate the eigenvalues. 
   If the matrix doesn't have any eigenvalues or the eigenvalues are imaginary numbers, 
   the program will interrupted here.
3. The program will calculate the eigenvectors.

The program was designed by Python.